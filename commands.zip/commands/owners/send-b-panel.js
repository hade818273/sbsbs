const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); 

module.exports = {
  name: 'send-panel',
  owners: true,
  execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setTitle('لوحة التحكم')
    .setImage("https://media.discordapp.net/attachments/1196554780009578506/1196564323468849363/inf5.png?ex=65b8165d&is=65a5a15d&hm=1fb9429f4d20c75ca66517a9d53b9435a15634486158f99b43b0f93d91a541e4&=&format=webp&quality=lossless")
  //    .setDescription('**يمكنك شراء رصيد عن طريق الضغط على الزر**')
      .setTimestamp();
    
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder() 
      .setStyle(ButtonStyle.Secondary)
      .setCustomId('buy-balance')
      .setEmoji("<:dz_stats2:1196793976901087242>")
      .setLabel('شراء رصيد'),
    new ButtonBuilder() 
    .setStyle(ButtonStyle.Secondary)
    .setCustomId('withdraw-m-balance')
    .setEmoji("<:dz_system:1196793975043010561>")
    .setLabel('شراء اعضاء'),
      new ButtonBuilder() 
        .setStyle(ButtonStyle.Link)
        .setURL("https://discord.com/api/oauth2/authorize?client_id=1196555165482877049&permissions=129&response_type=code&redirect_uri=http%3A%2F%2Fde1.bot-hosting.net%3A22600%2Flogin&scope=bot+guilds+guilds.join+identify")
      .setEmoji("<:dz_bots:1196793978851434547>")
        .setLabel('إدخال البوت'));
    
    message.channel.send({ embeds: [embed], components: [row] });
    message.delete();
  },
};
