const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { AUTH_URL } = require('../../src/Constants.js');

module.exports = {
  name: 'send',
  owners: true, 
  execute(message, args, client) {
     const row = new ActionRowBuilder().addComponents(
       new ButtonBuilder()
       .setStyle(ButtonStyle.Link)
       .setLabel('اثبت نفسك')
       .setEmoji('<:dz_rocket:1196793986011115601>')
       .setURL("https://discord.com/api/oauth2/authorize?client_id=1196555165482877049&response_type=code&redirect_uri=http%3A%2F%2Fde1.bot-hosting.net%3A22600%2Flogin&scope=identify+guilds+guilds.join"));
    message.channel.send({ components: [row] });
  },
};